package com.ph.remote.util;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class HttpUtils {

    private static final CloseableHttpClient httpclient = HttpClients.createDefault() ;

    public HttpUtils(){}


    private final String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6IjI0ZDhkNThiLWJlODQtNGQ2Zi1iZGI0LTQyN2MyNzY2MDlkNiIsImlhdCI6MTYwNDI5NTAzNCwic3ViIjoiZGV2ZWxvcGVyLzdiZDU5Nzk4LTQyYjYtOWM0Yy1iNjQ3LTZiMjIwMTZlYjZmOCIsInNjb3BlcyI6WyJjbGFzaCJdLCJsaW1pdHMiOlt7InRpZXIiOiJkZXZlbG9wZXIvc2lsdmVyIiwidHlwZSI6InRocm90dGxpbmcifSx7ImNpZHJzIjpbIjExMS4yMDUuNDMuMjQ4Il0sInR5cGUiOiJjbGllbnQifV19.LJpASqZ31guag1WvzpoGt3E-19kFWi8lgxo9rX8hWxIBS86kWOpVPSIPxYOhaEgRVCYafoLo0JJfXIfbdXfJWg";
	
    public String get(String url) {
        HttpGet httpget = new HttpGet(url);
        httpget.setHeader("823272114@qq.com", token);
        CloseableHttpResponse response = null;
        String result = null;
        try {
            //3.执行get请求并返回结果
            response = httpclient.execute(httpget);

            HttpEntity entity =  response.getEntity();
            if (entity != null) {
                result = EntityUtils.toString(entity);
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }finally {

            if(response != null){
                try {
                    response.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;
    }
}
