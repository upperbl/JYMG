package com.ph.remote.entity;


public class WarLeague {
    private Integer id;

    private String name;
}
