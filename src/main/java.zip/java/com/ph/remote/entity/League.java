package com.ph.remote.entity;


//联赛，指的是个人的杯段

public class League {

    private Integer id;

    private String name;

    private IconUrls iconUrls;
}
