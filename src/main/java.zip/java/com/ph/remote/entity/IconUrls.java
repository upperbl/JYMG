package com.ph.remote.entity;



public class IconUrls {
    private String small;

    private String large;

    private String medium;
}
